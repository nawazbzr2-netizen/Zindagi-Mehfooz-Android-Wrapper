// ============================================================
// location-service.js — the ONE place the app asks the phone for its location.
//
// Battery-friendly by design:
//   • Never keeps the GPS running. Every request is a single, quick, low-power fix
//     (network / Wi-Fi / cell based, enableHighAccuracy:false).
//   • The last known location is remembered. If it is fresh enough (30 min by default)
//     the phone is NOT asked again at all.
//   • Two screens asking at the same moment share ONE request.
//   • If the permission is already granted, checking it costs nothing (no GPS fix).
//
// Used by: location-gate.js (app start), login.html, main.js (daily "App Open"),
//          village-tracking.js (feeds every fix back via EpiLocation.remember()).
// ============================================================
(function(){
  var K_LAT = 'epi_login_lat', K_LNG = 'epi_login_lng', K_ACC = 'epi_loc_acc', K_T = 'epi_loc_t';
  var DEFAULT_MAX_AGE = 30 * 60 * 1000;
  var inflight = null;

  function ls(k){ try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v){ try { localStorage.setItem(k, String(v)); } catch (e) {} }

  // Last remembered location (any age) or null.
  function last(){
    var lat = parseFloat(ls(K_LAT)), lng = parseFloat(ls(K_LNG));
    if (!isFinite(lat) || !isFinite(lng)) return null;
    var acc = parseFloat(ls(K_ACC)), t = parseInt(ls(K_T), 10);
    return { lat: lat, lng: lng, accuracy: isFinite(acc) ? acc : null, t: isFinite(t) ? t : 0 };
  }

  function remember(lat, lng, accuracy){
    lsSet(K_LAT, lat); lsSet(K_LNG, lng);
    lsSet(K_ACC, accuracy == null ? '' : Math.round(accuracy));
    lsSet(K_T, Date.now());
  }

  // 'granted' | 'denied' | 'prompt' | 'unknown'  — no GPS fix is taken.
  function permission(){
    try {
      if (navigator.permissions && navigator.permissions.query) {
        return navigator.permissions.query({ name: 'geolocation' })
          .then(function(s){ return s.state; })
          .catch(function(){ return 'unknown'; });
      }
    } catch (e) {}
    return Promise.resolve('unknown');
  }

  // One low-power fix, or the remembered one. Always resolves (never rejects):
  //   { ok:true,  lat, lng, accuracy, cached:boolean }
  //   { ok:false, denied:boolean }
  function getOnce(opts){
    opts = opts || {};
    var maxAge = opts.maxAge == null ? DEFAULT_MAX_AGE : opts.maxAge;
    var l = last();
    if (l && l.t && Date.now() - l.t <= maxAge) {
      return Promise.resolve({ ok: true, lat: l.lat, lng: l.lng, accuracy: l.accuracy, cached: true });
    }
    if (!('geolocation' in navigator)) {
      return Promise.resolve(l ? { ok: true, lat: l.lat, lng: l.lng, accuracy: l.accuracy, cached: true } : { ok: false, denied: false });
    }
    if (inflight) return inflight;
    inflight = new Promise(function(resolve){
      navigator.geolocation.getCurrentPosition(
        function(pos){
          var c = pos.coords;
          remember(c.latitude, c.longitude, c.accuracy);
          resolve({ ok: true, lat: c.latitude, lng: c.longitude, accuracy: c.accuracy, cached: false });
        },
        function(err){
          if (err && err.code === 1) { resolve({ ok: false, denied: true }); return; }
          // GPS slow / off / no signal: fall back to the last known place if we have one
          resolve(l ? { ok: true, lat: l.lat, lng: l.lng, accuracy: l.accuracy, cached: true } : { ok: false, denied: false });
        },
        { enableHighAccuracy: false, timeout: opts.timeout || 15000, maximumAge: 10 * 60 * 1000 }
      );
    }).then(function(r){ inflight = null; return r; });
    return inflight;
  }

  window.EpiLocation = { getOnce: getOnce, last: last, remember: remember, permission: permission };
})();
