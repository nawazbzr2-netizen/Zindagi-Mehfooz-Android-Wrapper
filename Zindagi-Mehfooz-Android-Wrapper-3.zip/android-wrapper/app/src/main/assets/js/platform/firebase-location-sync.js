// ============================================================
// firebase-location-sync.js — AUTO + OFFLINE QUEUE
// ------------------------------------------------------------
// • While app is open: sample GPS every 30s (no button needed)
// • If offline or Firebase write fails → save to local queue
// • When internet returns / app reopens → flush queue automatically
// • On page hide/close → save last known fix into the queue
//
// Note: when the app is fully killed, the phone stops JS — GPS cannot
// keep sampling in the background. Queued points from when the app
// WAS open (including offline) are kept and sent on next online open.
// ============================================================
(function () {
  var INTERVAL_MS = 30 * 1000;
  var DEVICE_KEY = 'epi_device_id';
  var QUEUE_KEY = 'epi_loc_queue_v1';
  var MAX_QUEUE = 300;
  var timer = null;
  var watchId = null;
  var lastPushAt = 0;
  var lastFix = null;
  var lastStatus = '';
  var inflight = false;
  var started = false;
  var flushing = false;

  function deviceId() {
    try {
      var id = localStorage.getItem(DEVICE_KEY);
      if (id && id.length > 8) return id;
      id =
        'd_' +
        Date.now().toString(36) +
        '_' +
        Math.random().toString(36).slice(2, 10);
      localStorage.setItem(DEVICE_KEY, id);
      return id;
    } catch (e) {
      return 'd_anon_' + Date.now();
    }
  }

  function loginInfo() {
    try {
      return {
        name: localStorage.getItem('epi_login_name') || '',
        center: localStorage.getItem('epi_login_center') || '',
        district: localStorage.getItem('epi_login_district') || '',
        tehsil: localStorage.getItem('epi_login_tehsil') || '',
        uc: localStorage.getItem('epi_login_uc') || ''
      };
    } catch (e) {
      return { name: '', center: '', district: '', tehsil: '', uc: '' };
    }
  }

  function setStatus(msg) {
    lastStatus = msg || '';
    try {
      var el = document.getElementById('liveCloudStatus');
      if (el) el.textContent = lastStatus;
    } catch (e) {}
  }

  function loadQueue() {
    try {
      var q = JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]');
      return Array.isArray(q) ? q : [];
    } catch (e) {
      return [];
    }
  }

  function saveQueue(q) {
    try {
      if (q.length > MAX_QUEUE) q = q.slice(q.length - MAX_QUEUE);
      localStorage.setItem(QUEUE_KEY, JSON.stringify(q));
    } catch (e) {
      console.warn('loc queue full', e);
    }
  }

  function enqueue(payload) {
    var q = loadQueue();
    q.push(payload);
    saveQueue(q);
    setStatus('☁ آف لائن محفوظ · قطار میں ' + q.length + ' لوکیشن');
  }

  function buildPayload(lat, lng, accuracy) {
    var info = loginInfo();
    var id = deviceId();
    return {
      name: info.name || '—',
      center: info.center || '',
      district: info.district || '',
      tehsil: info.tehsil || '',
      uc: info.uc || '',
      lat: lat,
      lng: lng,
      accuracy: accuracy != null && isFinite(accuracy) ? Math.round(accuracy) : null,
      updatedAt: Date.now(),
      deviceId: id,
      queuedAt: Date.now()
    };
  }

  function isOnline() {
    return typeof navigator === 'undefined' || navigator.onLine !== false;
  }

  function writeLive(payload) {
    if (!window.EpiFirebase) return Promise.reject(new Error('no firebase'));
    var db = window.EpiFirebase.db();
    if (!db) return Promise.reject(new Error('no db'));
    var id = payload.deviceId || deviceId();
    var live = {
      name: payload.name,
      center: payload.center,
      district: payload.district,
      tehsil: payload.tehsil,
      uc: payload.uc,
      lat: payload.lat,
      lng: payload.lng,
      accuracy: payload.accuracy,
      updatedAt: payload.updatedAt || Date.now(),
      deviceId: id
    };
    return db.ref('locations/' + id).set(live);
  }

  function writeActivity(payload, eventType) {
    if (!window.EpiFirebase) return Promise.resolve();
    var db = window.EpiFirebase.db();
    if (!db) return Promise.resolve();
    var id = payload.deviceId || deviceId();
    var key = String(payload.updatedAt || Date.now());
    return db.ref('locationActivity/' + id + '/' + key).set({
      event: eventType || 'fix',
      lat: payload.lat,
      lng: payload.lng,
      accuracy: payload.accuracy,
      updatedAt: payload.updatedAt || Date.now(),
      name: payload.name,
      center: payload.center
    }).catch(function () {});
  }

  function writeHistory(payload) {
    if (!window.EpiFirebase) return Promise.resolve();
    var db = window.EpiFirebase.db();
    if (!db) return Promise.resolve();
    var id = payload.deviceId || deviceId();
    var key = String(payload.updatedAt || payload.queuedAt || Date.now());
    return db.ref('locationHistory/' + id + '/' + key).set({
      lat: payload.lat,
      lng: payload.lng,
      accuracy: payload.accuracy,
      updatedAt: payload.updatedAt || payload.queuedAt || Date.now()
    });
  }

  function flushQueue() {
    if (flushing) return Promise.resolve();
    if (!isOnline()) {
      var n = loadQueue().length;
      if (n) setStatus('☁ آف لائن · ' + n + ' لوکیشن محفوظ، انٹرنیٹ کا انتظار');
      return Promise.resolve();
    }
    var q = loadQueue();
    if (!q.length) return Promise.resolve();
    flushing = true;
    setStatus('☁ محفوظ لوکیشن بھیج رہے ہیں… (' + q.length + ')');

    // Send oldest first; keep live location as the newest
    var chain = Promise.resolve();
    var remaining = q.slice();
    var latest = remaining[remaining.length - 1];

    remaining.forEach(function (item, idx) {
      chain = chain.then(function () {
        return writeHistory(item).catch(function () {});
      });
    });

    chain = chain
      .then(function () {
        if (latest) return writeLive(latest);
      })
      .then(function () {
        saveQueue([]);
        lastPushAt = Date.now();
        setStatus('☁ قطار خالی · آٹو اپڈیٹ · ' + new Date().toLocaleTimeString());
      })
      .catch(function (err) {
        console.warn('flush queue', err);
        setStatus('☁ بھیجنے میں خرابی — بعد میں دوبارہ کوشش');
      })
      .then(function () {
        flushing = false;
      });

    return chain;
  }

  function sendOrQueue(lat, lng, accuracy) {
    lastFix = { lat: lat, lng: lng, accuracy: accuracy, t: Date.now() };
    var info = loginInfo();
    if (!(info.center && info.district)) {
      setStatus('☁ پہلے لاگ اِن مکمل کریں');
      return;
    }
    var payload = buildPayload(lat, lng, accuracy);

    if (!isOnline()) {
      enqueue(payload);
      return;
    }

    inflight = true;
    writeLive(payload)
      .then(function () {
        return writeActivity(payload, 'live');
      })
      .then(function () {
        return writeHistory(payload).catch(function () {});
      })
      .then(function () {
        lastPushAt = Date.now();
        setStatus('☁ آٹو اپڈیٹ · ' + new Date().toLocaleTimeString());
        // Also drain any leftover offline queue
        return flushQueue();
      })
      .catch(function (err) {
        console.warn('firebase push', err);
        enqueue(payload);
      })
      .then(function () {
        inflight = false;
      });
  }

  function pushOnce(forceFresh) {
    if (inflight) return;
    if (!window.EpiLocation) {
      setStatus('☁ لوکیشن سروس تیار نہیں');
      return;
    }
    var info = loginInfo();
    if (!(info.center && info.district)) {
      setStatus('☁ پہلے لاگ اِن مکمل کریں');
      return;
    }

    // If we have queued items and are online, flush first
    if (isOnline() && loadQueue().length) flushQueue();

    var maxAge = forceFresh ? 0 : 30 * 1000;
    window.EpiLocation.getOnce({ maxAge: maxAge, timeout: 20000 }).then(function (r) {
      if (!r || !r.ok) {
        setStatus('☁ GPS نہیں ملا — فون کی لوکیشن آن رکھیں');
        return;
      }
      sendOrQueue(r.lat, r.lng, r.accuracy);
    });
  }

  function startWatch() {
    if (watchId != null || !('geolocation' in navigator)) return;
    try {
      watchId = navigator.geolocation.watchPosition(
        function (pos) {
          var c = pos.coords;
          if (!c) return;
          try {
            if (window.EpiLocation) window.EpiLocation.remember(c.latitude, c.longitude, c.accuracy);
          } catch (e) {}
          lastFix = { lat: c.latitude, lng: c.longitude, accuracy: c.accuracy, t: Date.now() };
          if (Date.now() - lastPushAt < 25000 && isOnline()) return;
          sendOrQueue(c.latitude, c.longitude, c.accuracy);
        },
        function () {},
        { enableHighAccuracy: true, maximumAge: 15000, timeout: 25000 }
      );
    } catch (e) {}
  }

  function saveLastOnHide() {
    if (!lastFix) return;
    var info = loginInfo();
    if (!(info.center && info.district)) return;
    // Always stash last fix so if app is closed offline we still have it
    var payload = buildPayload(lastFix.lat, lastFix.lng, lastFix.accuracy);
    payload.updatedAt = lastFix.t || Date.now();
    var q = loadQueue();
    // Avoid duplicate if last queue item is almost the same time
    var last = q[q.length - 1];
    if (last && Math.abs((last.updatedAt || 0) - payload.updatedAt) < 10000) return;
    q.push(payload);
    saveQueue(q);
  }

  function start() {
    if (started) {
      flushQueue();
      return;
    }
    started = true;
    try {
      if (window.EpiFirebase) window.EpiFirebase.init();
    } catch (e) {}
    flushQueue();
    pushOnce(true);
    if (timer) clearInterval(timer);
    timer = setInterval(function () {
      pushOnce(true);
    }, INTERVAL_MS);
    startWatch();
  }

  function stop() {
    started = false;
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
    if (watchId != null && navigator.geolocation) {
      try {
        navigator.geolocation.clearWatch(watchId);
      } catch (e) {}
      watchId = null;
    }
  }

  try {
    window.addEventListener('online', function () {
      setStatus('☁ انٹرنیٹ واپس — محفوظ لوکیشن بھیج رہے ہیں…');
      flushQueue().then(function () {
        pushOnce(true);
      });
    });
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'hidden') saveLastOnHide();
      else if (document.visibilityState === 'visible') {
        flushQueue();
        pushOnce(true);
      }
    });
    window.addEventListener('pagehide', saveLastOnHide);
  } catch (e) {}

  window.EpiLocationSync = {
    start: start,
    stop: stop,
    pushOnce: function () {
      pushOnce(true);
    },
    flushQueue: flushQueue,
    deviceId: deviceId,
    lastStatus: function () {
      return lastStatus;
    },
    lastPushAt: function () {
      return lastPushAt;
    },
    queueLength: function () {
      return loadQueue().length;
    }
  };

  function boot() {
    setTimeout(start, 2000);
  }
  if (typeof document !== 'undefined') {
    if (document.readyState === 'complete') boot();
    else window.addEventListener('load', boot);
  }
})();
