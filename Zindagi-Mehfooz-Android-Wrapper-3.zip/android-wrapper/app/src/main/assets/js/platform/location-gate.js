// ============================================================
// location-gate.js
// ------------------------------------------------------------
// App will NOT open until the phone's Location is ON and this app
// has permission. If location is off / denied, a description page
// is shown (not a blank close). User can enable location and Retry.
// ============================================================
(function () {
  var gate = document.getElementById('locationGate');
  var wrap = document.getElementById('appWrap');
  if (!gate || !wrap) return;

  function reveal() {
    gate.style.display = 'none';
    gate.innerHTML = '';
    wrap.style.visibility = 'visible';
    // Start automatic location → server as soon as app is allowed
    try {
      if (window.EpiLocationSync && typeof window.EpiLocationSync.start === 'function') {
        window.EpiLocationSync.start();
      }
    } catch (e) {}
  }

  function showBlocked(reason) {
    wrap.style.visibility = 'hidden';
    gate.style.display = 'block';
    gate.style.overflow = 'auto';
    var detail =
      reason === 'denied'
        ? 'لوکیشن کی <b>اجازت بند</b> ہے۔ فون سیٹنگ میں اس ایپ کو Location اجازت دیں۔'
        : reason === 'off'
          ? 'فون کی <b>Location / GPS بند</b> ہے۔ پہلے Location آن کریں۔'
          : reason === 'unsupported'
            ? 'اس ڈیوائس پر GPS دستیاب نہیں۔'
            : 'لوکیشن نہیں مل سکی۔ Location آن رکھیں اور دوبارہ کوشش کریں۔';

    gate.innerHTML =
      '<div dir="rtl" style="max-width:420px;margin:40px auto;padding:20px;font-family:system-ui,sans-serif;color:#1a1a1a;">' +
      '<div style="background:#fff;border-radius:16px;padding:22px;box-shadow:0 2px 12px rgba(0,0,0,.08);">' +
      '<div style="font-size:40px;text-align:center;">📍</div>' +
      '<h1 style="margin:8px 0 12px;font-size:20px;text-align:center;">لوکیشن ضروری ہے</h1>' +
      '<p style="font-size:14.5px;line-height:1.7;margin:0 0 12px;">' +
      'یہ ایپ <b>صرف اس وقت چلتی ہے</b> جب موبائل کی Location آن ہو اور ایپ کو لوکیشن کی اجازت دی گئی ہو۔' +
      '</p>' +
      '<p style="font-size:14px;line-height:1.7;margin:0 0 12px;color:#9d174d;">' +
      detail +
      '</p>' +
      '<div style="background:#f8fafc;border-radius:12px;padding:12px 14px;font-size:13.5px;line-height:1.65;margin-bottom:16px;">' +
      '<b>کیا کریں:</b><br>' +
      '۱) فون سیٹنگ → Location → <b>آن</b><br>' +
      '۲) اس ایپ کی Permission → Location → Allow<br>' +
      '۳) نیچے <b>دوبارہ کوشش</b> دبائیں' +
      '</div>' +
      '<button type="button" id="locGateRetry" style="width:100%;padding:14px;border:none;border-radius:12px;background:#2563eb;color:#fff;font-size:16px;font-weight:700;cursor:pointer;">🔄 دوبارہ کوشش</button>' +
      '<p style="font-size:12px;color:#6b7280;text-align:center;margin:14px 0 0;line-height:1.5;">' +
      'ایپ کھلتے ہی لوکیشن سرور پر خودکار جاتی رہتی ہے۔ ایپ بند ہونے کے دوران فون ویب ایپ کا GPS نہیں چلاتا — دوبارہ کھلتے ہی محفوظ/نیا ڈیٹا بھیج دیا جاتا ہے۔' +
      '</p>' +
      '</div></div>';

    var btn = document.getElementById('locGateRetry');
    if (btn) btn.onclick = function () {
      gate.innerHTML = '<div style="padding:60px 20px;text-align:center;color:#6b7280;">لوکیشن چیک ہو رہی ہے…</div>';
      setTimeout(check, 300);
    };
  }

  function askOnce() {
    if (!window.EpiLocation) {
      showBlocked('unsupported');
      return;
    }
    window.EpiLocation.getOnce({ maxAge: 0, timeout: 25000 }).then(function (r) {
      if (r && r.ok) {
        reveal();
        return;
      }
      if (r && r.denied) showBlocked('denied');
      else showBlocked('off');
    });
  }

  function check() {
    if (!('geolocation' in navigator) || !window.EpiLocation) {
      showBlocked('unsupported');
      return;
    }
    window.EpiLocation.permission().then(function (state) {
      if (state === 'denied') {
        showBlocked('denied');
        return;
      }
      // Always take a real fix so "Location off" is caught even if permission was granted earlier
      askOnce();
    });
  }

  check();
})();
