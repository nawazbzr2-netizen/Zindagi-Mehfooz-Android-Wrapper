// Main box = 0–11 month schedule (birth doses through Measles1) — Measles2 is a
// 12–23 month booster and does not belong here, so it's left out entirely.
const orderMain = ['BCG','HepB','OPV0','Penta1','Penta2','Penta3','Measles1'];
const order1223 = ['BCG','OPV0','Penta1','Penta2','Penta3','Measles1','Measles2'];

// Gender helpers — records store gender as 'M' | 'F' | null
function genderOf(r){
  const g = r && r.gender;
  if (g === 'M' || g === 'F') return g;
  return null;
}
function emptyMF(){ return { M: 0, F: 0, U: 0, total: 0 }; }
function addGender(bucket, r){
  if (!bucket) return;
  const g = genderOf(r);
  if (g === 'M') bucket.M++;
  else if (g === 'F') bucket.F++;
  else bucket.U++;
  bucket.total++;
}
// Centered "M 53 - F 68" + total line (easy to read)
function mfText(mf){
  if (!mf) return '0';
  const t = mf.total || ((mf.M || 0) + (mf.F || 0) + (mf.U || 0));
  if (!t) return '0';
  return 'M ' + String(mf.M || 0).padStart(2, '0') + ' - F ' + String(mf.F || 0).padStart(2, '0') +
    '\n' + t;
}
function mfOneLine(mf){
  if (!mf) return '0';
  const t = mf.total || ((mf.M || 0) + (mf.F || 0) + (mf.U || 0));
  if (!t) return '0';
  return 'M ' + (mf.M || 0) + ' - F ' + (mf.F || 0) + '\u00a0\u00a0\u00a0\u00a0' + t;
}

// One result card: label | Male/Female (center) | big total (same size as T-D)
function mfBlockHtml(mf){
  const m = (mf && mf.M) || 0;
  const f = (mf && mf.F) || 0;
  return `<div class="stat-mf" aria-label="M ${m}, F ${f}">
    <div class="mf-row">M ${m}</div>
    <div class="mf-row">F ${f}</div>
  </div>`;
}
function statCardHtml(tag, kind, countOrMf, label, extraClass){
  const isMf = countOrMf && typeof countOrMf === 'object' && ('M' in countOrMf || 'total' in countOrMf);
  const count = isMf ? (countOrMf.total || 0) : (countOrMf || 0);
  const mid = isMf ? mfBlockHtml(countOrMf) : '';
  return `
    <div class="stat-card clickable ${extraClass || ''}" data-tag="${tag}" data-kind="${kind}">
      <div class="stat-info">
        <div class="stat-label">${label}</div>
        <div class="stat-hint">Tap to view list ›</div>
      </div>
      ${mid}
      <div class="stat-n">${count}</div>
    </div>`;
}

// Compact table: Vaccine | Male/Female | Total
function countTableRowsHtml(order, counts, labels, kind, ageHint){
  const rows = order.filter(k => {
    const c = counts[k];
    if (!c) return false;
    if (typeof c === 'object') return (c.total || 0) > 0;
    return c > 0;
  }).map(k => {
    const c = counts[k];
    const isMf = c && typeof c === 'object' && ('M' in c || 'F' in c);
    if (isMf) {
      return `<tr class="ct-row-click" data-tag="${k}" data-kind="${kind || ''}" data-age-hint="${ageHint || ''}" style="cursor:pointer;">
      <td class="ct-label">${labels[k] || k}</td>
      <td class="ct-mf-cell"><div class="mf-row">M ${c.M || 0}</div><div class="mf-row">F ${c.F || 0}</div></td>
      <td class="ct-n ct-n-big">${c.total || 0}</td>
    </tr>`;
    }
    return `<tr class="ct-row-click" data-tag="${k}" data-kind="${kind || ''}" data-age-hint="${ageHint || ''}" style="cursor:pointer;">
      <td class="ct-label">${labels[k] || k}</td>
      <td class="ct-mf-cell ct-empty-mf">—</td>
      <td class="ct-n ct-n-big">${c}</td>
    </tr>`;
  });
  if (!rows.length) return '<tr><td colspan="3" class="ct-empty">There is Nothing</td></tr>';
  return rows.join('');
}

function countTableCardHtml(title, order, counts, labels, kind, ageHint){
  const hasAny = order.some(k => {
    const c = counts[k];
    if (!c) return false;
    return typeof c === 'object' ? (c.total || 0) > 0 : c > 0;
  });
  if (!hasAny) return '';
  const hasMf = order.some(k => counts[k] && typeof counts[k] === 'object' && ('M' in counts[k] || 'F' in counts[k]));
  const head = hasMf
    ? '<tr><th>Vaccine / Dose</th><th style="text-align:center;">M / F</th><th style="text-align:center;">Total</th></tr>'
    : '<tr><th>Vaccine / Dose</th><th colspan="2" style="text-align:center;">Count</th></tr>';
  // For non-MF tables still 2 meaningful cols — simplify body when !hasMf
  let body;
  if (!hasMf) {
    body = order.filter(k => (counts[k] || 0) > 0).map(k =>
      `<tr class="ct-row-click" data-tag="${k}" data-kind="${kind || ''}" data-age-hint="${ageHint || ''}" style="cursor:pointer;">
        <td class="ct-label">${labels[k] || k}</td>
        <td colspan="2" class="ct-n ct-n-big">${counts[k]}</td>
      </tr>`
    ).join('') || '<tr><td colspan="3" class="ct-empty">There is Nothing</td></tr>';
  } else {
    body = countTableRowsHtml(order, counts, labels, kind, ageHint);
  }
  return `<div class="card count-table-card">
    <h2 class="ct-title">${title}</h2>
    <table class="count-table">
      <thead>${head}</thead>
      <tbody>${body}</tbody>
    </table>
  </div>`;
}

// Group page / Results by Date show ONLY the By Age summary.
function dashboardHTML(){
  return `
    <div class="card">
      <h2 style="margin-top:0;text-align:center;">By Age</h2>
      <div class="stat-list">
        <div class="stat-card age clickable" data-age="b0">
          <div class="stat-info"><div class="stat-label">0–11 Months</div><div class="stat-hint">Tap to view EPI Schedule ›</div></div>
          <div class="stat-mf" data-slot-mf="ageB0"><div class="mf-row">M 0</div><div class="mf-row">F 0</div></div>
          <div class="stat-n" data-slot="ageB0">0</div>
          <button type="button" class="age-pdf-btn" data-age="b0" title="Share / Download 0–11 Months">📤</button>
        </div>
        <div class="stat-card age clickable" data-age="b1">
          <div class="stat-info"><div class="stat-label">12–23 Months</div><div class="stat-hint">Tap to view EPI Details ›</div></div>
          <div class="stat-mf" data-slot-mf="ageB1"><div class="mf-row">M 0</div><div class="mf-row">F 0</div></div>
          <div class="stat-n" data-slot="ageB1">0</div>
          <button type="button" class="age-pdf-btn" data-age="b1" title="Share / Download 12–23 Months">📤</button>
        </div>
        <div class="stat-card age clickable" data-age="b2">
          <div class="stat-info"><div class="stat-label">24–59 Months</div><div class="stat-hint">Tap to view EPI Details ›</div></div>
          <div class="stat-mf" data-slot-mf="ageB2"><div class="mf-row">M 0</div><div class="mf-row">F 0</div></div>
          <div class="stat-n" data-slot="ageB2">0</div>
          <button type="button" class="age-pdf-btn" data-age="b2" title="Share / Download 24–59 Months">📤</button>
        </div>
        <div class="stat-card age clickable" data-age="tt">
          <div class="stat-info"><div class="stat-label">All T-D</div><div class="stat-hint">Tap to view T-D Counts ›</div></div>
          <div class="stat-n" data-slot="ageTt">0</div>
          <button type="button" class="age-pdf-btn" data-age="tt" title="Share / Download All T-D">📤</button>
        </div>
        <div class="stat-card age clickable" data-age="all">
          <div class="stat-info"><div class="stat-label">All Category</div><div class="stat-hint">Tap to view all age groups ›</div></div>
          <div class="stat-mf" data-slot-mf="ageAll"><div class="mf-row">M 0</div><div class="mf-row">F 0</div></div>
          <div class="stat-n" data-slot="ageAll">0</div>
          <button type="button" class="age-pdf-btn" data-age="all" title="Share / Download All Category">📤</button>
        </div>
      </div>
    </div>`;
}

function setSlotMf(containerEl, slot, list, totalOnly){
  const totalEl = containerEl.querySelector('[data-slot="' + slot + '"]');
  const mfEl = containerEl.querySelector('[data-slot-mf="' + slot + '"]');
  const mf = emptyMF();
  (list || []).forEach(r => addGender(mf, r));
  if (totalEl) {
    totalEl.textContent = String(mf.total);
    totalEl.classList.remove('stat-n-mf');
    totalEl.classList.add('stat-n');
  }
  if (totalOnly) {
    if (mfEl) mfEl.style.display = 'none';
    return;
  }
  if (mfEl) {
    mfEl.style.display = '';
    mfEl.innerHTML = '<div class="mf-row">M ' + mf.M + '</div><div class="mf-row">F ' + mf.F + '</div>';
  }
}

// onAgeClick(ageKey) — ageKey is 'b0' | 'b1' | 'b2' | 'tt' | 'all'
function fillDashboard(containerEl, recs, excludeMeasles2FromB, onAgeClick){
  containerEl.innerHTML = dashboardHTML();
  const ageRecords = { b0:[], b1:[], b2:[] };
  const ttRecords = [];
  for (const r of recs) {
    const isTt = isTtRecord(r.doses);
    if (isTt) { ttRecords.push(r); continue; }
    const am = ageMonths(r.dob, r.vaccDate);
    const bracket = am <= 11 ? 'b0' : (am <= 23 ? 'b1' : 'b2');
    ageRecords[bracket].push(r);
  }
  const allCategoryList = ageRecords.b0.concat(ageRecords.b1, ageRecords.b2, ttRecords);

  setSlotMf(containerEl, 'ageB0', ageRecords.b0);
  setSlotMf(containerEl, 'ageB1', ageRecords.b1);
  setSlotMf(containerEl, 'ageB2', ageRecords.b2);
  setSlotMf(containerEl, 'ageTt', ttRecords, true);
  setSlotMf(containerEl, 'ageAll', allCategoryList);

  const countsByKey = {
    b0: ageRecords.b0.length,
    b1: ageRecords.b1.length,
    b2: ageRecords.b2.length,
    tt: ttRecords.length,
    all: allCategoryList.length
  };

  if (typeof onAgeClick === 'function') {
    containerEl.querySelectorAll('.stat-card.age.clickable').forEach(el => {
      el.addEventListener('click', async (e) => {
        if (e.target.closest && e.target.closest('.age-pdf-btn')) return;
        const key = el.dataset.age;
        if (!countsByKey[key]) {
          if (typeof alertDialog === 'function') await alertDialog('There is Nothing');
          else if (typeof backupMsg === 'function') backupMsg('There is Nothing', true);
          return;
        }
        onAgeClick(key);
      });
    });
  }

  const ageGroups = {
    b0:  { label: '0–11 Months', list: ageRecords.b0 },
    b1:  { label: '12–23 Months', list: ageRecords.b1 },
    b2:  { label: '24–59 Months', list: ageRecords.b2 },
    tt:  { label: 'All T-D', list: ttRecords },
    all: { label: 'All Category', list: allCategoryList }
  };
  containerEl.querySelectorAll('.age-pdf-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const key = btn.dataset.age;
      const g = ageGroups[key];
      if (!g) return;
      if (!g.list.length) {
        if (typeof alertDialog === 'function') await alertDialog('There is Nothing');
        else if (typeof backupMsg === 'function') backupMsg('There is Nothing', true);
        return;
      }
      const filenameBase = (typeof resultsFileName === 'function') ? resultsFileName(key, null) : null;
      const breadcrumb = (typeof resultsBreadcrumb === 'function') ? resultsBreadcrumb(key, null) : null;
      runRecordsExportFlow(g.label + ' Results', g.list, 'age-' + key, filenameBase, breadcrumb);
    });
  });
}

function bumpVaccineMf(map, key, r){
  if (!map[key]) map[key] = emptyMF();
  addGender(map[key], r);
}

// Build the vaccine / TT count cards for one age page (or all categories).
function ageDashCardsHTML(recs, ageKey, excludeMeasles2FromB){
  const epiCounts = {};
  const ttCounts = {};
  const epi1223 = {};
  const epi24 = {};

  for (const r of recs) {
    const isTt = isTtRecord(r.doses);
    const am = ageMonths(r.dob, r.vaccDate);

    classifyTT(r.doses).forEach(t => { bumpVaccineMf(ttCounts, t, r); });

    if (!isTt) {
      if (ageKey === 'b0' || ageKey === 'all') {
        if (ageKey === 'all' || am <= 11) {
          classifyEpi(r.doses).forEach(t => {
            if (t === 'Measles2') return;
            bumpVaccineMf(epiCounts, t, r);
          });
        }
      }
      if (ageKey === 'b1' || ageKey === 'all') {
        if (am >= 12 && am <= 23) {
          classifyEpi(r.doses).forEach(t => {
            if (t === 'Measles2' && (excludeMeasles2FromB || isTt)) return;
            bumpVaccineMf(epi1223, t, r);
          });
        }
      }
      if (ageKey === 'b2' || ageKey === 'all') {
        if (am >= 24) {
          classifyEpi(r.doses).forEach(t => {
            if (t === 'Measles2' && (excludeMeasles2FromB || isTt)) return;
            bumpVaccineMf(epi24, t, r);
          });
        }
      }
    }
  }

  if (ageKey === 'all') {
    let html = '';
    html += countTableCardHtml('0–11 Months', orderMain, epiCounts, EPI_LABELS, 'main', 'b0');
    html += countTableCardHtml('12–23 Months', order1223, epi1223, EPI_LABELS, '1223', 'b1');
    html += countTableCardHtml('24–59 Months', order1223, epi24, EPI_LABELS, '24plus', 'b2');
    const ttTotals = {};
    TT_ORDER.forEach(k => { if (ttCounts[k]) ttTotals[k] = ttCounts[k].total; });
    html += countTableCardHtml('All T-D', TT_ORDER, ttTotals, TT_LABELS, 'tt', 'tt');
    if (!html) {
      html = '<div class="card"><div class="note" style="text-align:center;margin:0;">There is Nothing</div></div>';
    }
    return html;
  }

  let html = '';
  if (ageKey === 'b0') {
    const items = orderMain.filter(k => (epiCounts[k] && epiCounts[k].total > 0))
      .map(k => statCardHtml(k, 'main', epiCounts[k], EPI_LABELS[k])).join('');
    html += `<div class="card"><h2 style="margin-top:0;text-align:center;">0–11 Months</h2><div class="stat-list">` +
      (items || '<div class="note" style="text-align:center;">There is Nothing</div>') +
      `</div></div>`;
  }
  if (ageKey === 'b1') {
    const items = order1223.filter(k => (epi1223[k] && epi1223[k].total > 0))
      .map(k => statCardHtml(k, '1223', epi1223[k], EPI_LABELS[k])).join('');
    html += `<div class="card"><h2 style="margin-top:0;text-align:center;">12–23 Months</h2><div class="stat-list">` +
      (items || '<div class="note" style="text-align:center;">There is Nothing</div>') +
      `</div></div>`;
  }
  if (ageKey === 'b2') {
    const items = order1223.filter(k => (epi24[k] && epi24[k].total > 0))
      .map(k => statCardHtml(k, '24plus', epi24[k], EPI_LABELS[k])).join('');
    html += `<div class="card"><h2 style="margin-top:0;text-align:center;">24–59 Months</h2><div class="stat-list">` +
      (items || '<div class="note" style="text-align:center;">There is Nothing</div>') +
      `</div></div>`;
  }
  if (ageKey === 'tt') {
    const items = TT_ORDER.filter(k => (ttCounts[k] && ttCounts[k].total > 0))
      .map(k => statCardHtml(k, 'tt', ttCounts[k].total, TT_LABELS[k], 'tt')).join('');
    html += `<div class="card"><h2 style="margin-top:0;text-align:center;">All T-D</h2><div class="stat-list">` +
      (items || '<div class="note" style="text-align:center;">There is Nothing</div>') +
      `</div></div>`;
  }
  return html;
}

// records matching one specific box's tag, mirroring the exact rule that box was counted with
function recordsForTag(recs, tag, kind, excludeMeasles2FromB, ageKeyHint){
  if (kind === 'tt') return recs.filter(r => classifyTT(r.doses).includes(tag));
  if (kind === '1223') {
    return recs.filter(r => {
      const am = ageMonths(r.dob, r.vaccDate);
      if (am < 12 || am > 23) return false;
      const isTt = isTtRecord(r.doses);
      if (tag === 'Measles2' && (excludeMeasles2FromB || isTt)) return false;
      return classifyEpi(r.doses).includes(tag);
    });
  }
  if (kind === '24plus') {
    return recs.filter(r => {
      const am = ageMonths(r.dob, r.vaccDate);
      if (am < 24) return false;
      const isTt = isTtRecord(r.doses);
      if (tag === 'Measles2' && (excludeMeasles2FromB || isTt)) return false;
      return classifyEpi(r.doses).includes(tag);
    });
  }
  // 'main' — 0–11 Months. When ageKeyHint is 'b0', only 0–11 month
  // children; otherwise all non-TT records with that vaccine.
  return recs.filter(r => {
    if (isTtRecord(r.doses)) return false;
    if (ageKeyHint === 'b0') {
      const am = ageMonths(r.dob, r.vaccDate);
      if (am > 11) return false;
    }
    return classifyEpi(r.doses).includes(tag);
  });
}
