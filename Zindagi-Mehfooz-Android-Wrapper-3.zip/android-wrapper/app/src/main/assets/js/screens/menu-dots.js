// ============================================================
// ⋮ MENU (three dots) — top-left of every page.
// Opens a side drawer showing the logged-in user name + centre name, then:
//   Offline Data Sync   (does nothing for now — feature will be linked later)
//   Insert              Daily Immunization -> Results by Date
//                       Children Defaulters -> Defaulter Children result
//                       QR code -> QR Codes result
//                       Women Defaulters, Women Identified, Zero Dose,
//                       Zero Dose in Child Registry -> do nothing yet (link later)
//   Settings            -> login page, pre-filled with the current login (editable)
//   Exit                -> same as the old Logout (clears login, back to login page)
// ============================================================
(function(){
  function lsGet(k){ try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }

  const css = document.createElement('style');
  css.textContent = `
  .dots-btn{position:absolute;top:10px;left:10px;right:auto;z-index:40;width:34px;height:34px;border-radius:50%;border:none;background:rgba(255,255,255,.24);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;}
  .dots-btn:active{background:rgba(255,255,255,.4);transform:scale(.94);}
  /* On result pages: left corner of the title band (exit stays top-right). */
  .dots-btn.on-title{top:14px;left:12px;right:auto;background:rgba(3,105,161,.18);color:var(--ink,#0f172a);border:1px solid rgba(3,105,161,.25);}
  /* Space for ⋮ on the left and quit on the right */
  #resultsWrap h1.page-title{padding-left:52px;padding-right:52px;text-align:center;}
  .hub-header{position:relative;}
  .hub-header .htitle{padding-left:44px;padding-right:44px;}
  .dm-drawer{right:auto;left:0;}
  .dm-back{position:fixed;inset:0;z-index:80;background:rgba(0,0,0,.5);display:none;}
  .dm-drawer{position:fixed;top:0;bottom:0;left:0;width:84%;max-width:340px;background:#fff;z-index:81;transform:translateX(-102%);transition:transform .22s ease;display:flex;flex-direction:column;overflow-y:auto;box-shadow:4px 0 20px rgba(0,0,0,.3);}
  .dm-drawer.open{transform:translateX(0);}
  .dm-head{background:linear-gradient(135deg,var(--hdr-a,#0369a1),var(--hdr-b,#0ea5e9));color:#fff;padding:calc(26px + env(safe-area-inset-top,0px)) 18px 20px;border-radius:0 0 26px 0;}
  .dm-name{font-size:22px;font-weight:800;line-height:1.3;word-break:break-word;}
  .dm-center{font-size:14.5px;margin-top:6px;opacity:.95;word-break:break-word;}
  .dm-sec{padding:14px 18px 6px;font-size:13.5px;color:#666;font-weight:700;}
  .dm-item{display:flex;align-items:center;gap:16px;width:100%;padding:14px 18px;border:none;background:none;font-size:15.5px;color:#222;text-align:left;cursor:pointer;font-family:inherit;}
  .dm-item:active{background:#eef2f5;}
  .dm-item .dm-ico{width:24px;text-align:center;font-size:19px;flex:0 0 24px;}
  .dm-sep{height:1px;background:#e4e4e4;margin:8px 0;}
  `;
  document.head.appendChild(css);

  const dotsSvg = '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><circle cx="12" cy="5" r="2.2"/><circle cx="12" cy="12" r="2.2"/><circle cx="12" cy="19" r="2.2"/></svg>';
  const btn = document.createElement('button');
  btn.type = 'button'; btn.className = 'dots-btn'; btn.setAttribute('aria-label', 'Menu');
  btn.innerHTML = dotsSvg;

  const back = document.createElement('div'); back.className = 'dm-back';
  const drawer = document.createElement('div'); drawer.className = 'dm-drawer';
  drawer.innerHTML =
    '<div class="dm-head"><div class="dm-name" id="dmName"></div><div class="dm-center" id="dmCenter"></div></div>' +
    '<button type="button" class="dm-item" data-act="sync" style="margin-top:8px;"><span class="dm-ico">☁️</span>Offline Data Sync</button>' +
    '<div class="dm-sep"></div>' +
    '<div class="dm-sec">Insert</div>' +
    '<button type="button" class="dm-item" data-act="daily"><span class="dm-ico">📄</span>Daily Immunization</button>' +
    '<button type="button" class="dm-item" data-act="defaulters"><span class="dm-ico">📋</span>Children Defaulters</button>' +
    '<button type="button" class="dm-item" data-act="qr"><span class="dm-ico">▦</span>QR code</button>' +
    '<button type="button" class="dm-item" data-act="future"><span class="dm-ico">📄</span>Women Defaulters</button>' +
    '<button type="button" class="dm-item" data-act="future"><span class="dm-ico">📄</span>Women Identified</button>' +
    '<button type="button" class="dm-item" data-act="future"><span class="dm-ico">📄</span>Zero Dose</button>' +
    '<button type="button" class="dm-item" data-act="future"><span class="dm-ico">📄</span>Zero Dose in Child Registry</button>' +
    '<div class="dm-sep"></div>' +
    '<button type="button" class="dm-item" data-act="settings"><span class="dm-ico">⚙️</span>Settings</button>' +
    '<button type="button" class="dm-item" data-act="exit"><span class="dm-ico">🚪</span>Exit</button>';

  function isShown(id){ const el = document.getElementById(id); return !!el && el.style.display !== 'none'; }

  // Put the ⋮ button in the top-left corner of whichever page is showing.
  function placeBtn(){
    const wrap = document.getElementById('appWrap');
    if (!wrap) return;
    if (btn.parentNode !== wrap) { wrap.style.position = 'relative'; wrap.insertBefore(btn, wrap.firstChild); }
    const onHeader = isShown('uploadView') && !isShown('resultsWrap') || isShown('hubView') && isShown('resultsWrap');
    btn.classList.toggle('on-title', !onHeader);
  }

  function openMenu(){
    var uc = lsGet('epi_login_uc'), dist = lsGet('epi_login_district');
    document.getElementById('dmName').textContent = uc || dist || 'EPI User';
    document.getElementById('dmCenter').textContent = lsGet('epi_login_center');
    back.style.display = 'block';
    requestAnimationFrame(() => drawer.classList.add('open'));
  }
  function closeMenu(){
    drawer.classList.remove('open');
    setTimeout(() => { back.style.display = 'none'; }, 220);
  }

  function openResultsView(fn){
    try { if (typeof renderResults === 'function' && typeof loadStore === 'function') renderResults(loadStore(), true); } catch (e) {}
    ['qrDeleteView', 'qrCodeSection', 'savedFilesSection'].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = 'none'; });
    document.getElementById('uploadView').style.display = 'none';
    document.getElementById('resultsWrap').style.display = 'block';
    fn();
  }

  async function doExit(){
    const ok = await confirmDialog('Exit? You will need to log in again next time.', 'Yes', 'No', true);
    if (!ok) return;
    if (typeof window.epiClearLogin === 'function') window.epiClearLogin();
    window.location.replace('login.html');
  }

  drawer.addEventListener('click', function(ev){
    const it = ev.target.closest('[data-act]');
    if (!it) return;
    const act = it.getAttribute('data-act');
    if (act === 'sync' || act === 'future') return;                       // intentionally does nothing (future feature)
    closeMenu();
    if (act === 'daily') openResultsView(() => showDateView());
    else if (act === 'defaulters') openResultsView(() => showDefaulterChildrenView());
    else if (act === 'qr') openResultsView(() => showQrResultView());
    else if (act === 'settings') window.location.href = 'login.html?edit=1';
    else if (act === 'exit') doExit();
  });
  back.addEventListener('click', closeMenu);
  btn.addEventListener('click', openMenu);

  document.body.appendChild(back);
  document.body.appendChild(drawer);
  placeBtn();
  setInterval(placeBtn, 300);
})();
