function visibleTitle(id, fallback){
  const el = document.getElementById(id);
  const t = el ? el.textContent.trim() : '';
  return t || fallback;

}

// (downloadBlobFile lives in js/platform/downloads.js)

async function exportRecordsPdf(title, records, slug){
  if (!records || !records.length) { backupMsg('There is Nothing', true); return; }
  if (records.length > 1500 && !await confirmDialog(`This list has ${records.length} records. The PDF will be large and may take a minute.`, 'Create PDF')) return;
  backupMsg('Creating PDF… please wait.');
  await new Promise(res => setTimeout(res, 30));
  try {
    const blob = await buildRecordsPdf(title, records);
    downloadBlobFile(`EPI-${slug}-${fileStamp()}.pdf`, blob);
    backupMsg('File Saved in Download File.');
  } catch (e) {
    console.error('pdf failed', e);
    if (buildPrintDoc(title, records) && typeof window.print === 'function') {
      backupMsg('PDF file could not be built here — opening the print dialog instead.', true);
      setTimeout(() => window.print(), 80);
    } else {
      backupMsg('PDF could not be created on this device.', true);
    }
  }
}

// Same PDF, but handed to the device's native Share sheet instead of the
// Downloads folder — falls back to a normal download if sharing files isn't
// supported here (older WebViews / desktop browsers).
async function shareRecordsPdf(title, records, slug){
  if (!records || !records.length) { backupMsg('There is Nothing', true); return; }
  if (records.length > 1500 && !await confirmDialog(`This list has ${records.length} records. The PDF will be large and may take a minute.`, 'Create PDF')) return;
  backupMsg('Creating PDF to share… please wait.');
  await new Promise(res => setTimeout(res, 30));
  try {
    const blob = await buildRecordsPdf(title, records);
    const filename = `EPI-${slug}-${fileStamp()}.pdf`;
    const result = await shareOrDownloadBlob(blob, filename, title);
    if (result === 'cancelled') { backupMsg('Share cancelled.'); return; }
    if (result === 'shared') { backupMsg('✔ Share sheet opened.'); return; }
    if (result === 'shared-text') { backupMsg('✔ Share opened — PDF also saved to Downloads.'); return; }
    backupMsg('File Saved in Download File.');
  } catch (e) {
    if (e && e.name === 'AbortError') { backupMsg('Share cancelled.'); return; }
    console.error('share failed', e);
    backupMsg('Could not share the PDF on this device.', true);
  }
}

// ---------- Unified export flow: choose Share/Download, then Card/Print
// style, then build and hand off the right PDF. Used everywhere a person
// can export a list of child records. ----------

// Hands a finished PDF to the person: saved to Downloads (+ notification-bar
// entry, see downloads.js) or given to the phone's Share sheet.
async function deliverPdf(action, blob, filename, title, countLabel){
  if (action === 'download') {
    const ok = downloadBlobFile(filename, blob);
    if (ok === false) backupMsg('Could not save the PDF on this device.', true);
    else backupMsg('File Saved in Download File.');
    return;
  }
  try {
    const result = await shareOrDownloadBlob(blob, filename, title);
    if (result === 'cancelled') { backupMsg('Share cancelled.'); return; }
    if (result === 'shared') { backupMsg('✔ Share sheet opened.'); return; }
    if (result === 'shared-text') { backupMsg('✔ Share opened — PDF also saved to Downloads.'); return; }
    backupMsg('File Saved in Download File.');
  } catch (e) {
    if (e && e.name === 'AbortError') { backupMsg('Share cancelled.'); return; }
    console.error('deliverPdf', e);
    downloadBlobFile(filename, blob);
    backupMsg('File Saved in Download File.');
  }
}

async function runRecordsExportFlow(title, records, slug, filenameBase, breadcrumb){
  if (!records || !records.length) { if (typeof alertDialog==='function') alertDialog('There is Nothing'); else backupMsg('There is Nothing', true); return; }
  const action = await chooseAction();
  if (!action) return;
  const style = await chooseExportStyle();
  if (!style) return;
  if (records.length > 1500 && !await confirmDialog(`This list has ${records.length} records. The PDF will be large and may take a minute.`, 'Continue')) return;

  backupMsg(`Creating PDF${action === 'share' ? ' to share' : ''}… please wait.`);
  await new Promise(res => setTimeout(res, 30));
  const slugFull = slug + (style === 'card' ? '-cards' : '');
  try {
    const blob = style === 'card' ? await buildRecordCardsPdf(title, records, breadcrumb) : await buildRecordsPdf(title, records, breadcrumb);
    const filename = filenameBase
      ? `${filenameBase}${style === 'card' ? ' - Cards' : ''}.pdf`
      : `EPI-${slugFull}-${fileStamp()}.pdf`;
    await deliverPdf(action, blob, filename, title, `${records.length} record(s)`);
  } catch (e) {
    if (e && e.name === 'AbortError') { backupMsg('Share cancelled.'); return; }
    console.error('export failed', e);
    if (style === 'print' && buildPrintDoc(title, records) && typeof window.print === 'function') {
      backupMsg('PDF file could not be built here — opening the print dialog instead.', true);
      setTimeout(() => window.print(), 80);
    } else {
      backupMsg('PDF could not be created on this device.', true);
    }
  }
}

// Search Records: share/download ONE child's details. Card Style only — so
// there is no style question, just Share or Download.
async function runSingleCardExportFlow(record){
  if (!record) { backupMsg('Nothing to share for this card.', true); return; }
  const action = await chooseAction();
  if (!action) return;
  backupMsg(`Creating card${action === 'share' ? ' to share' : ''}… please wait.`);
  await new Promise(res => setTimeout(res, 30));
  try {
    const title = record.name ? `Child Record — ${record.name}` : 'Child Record';
    const blob = await buildRecordCardsPdf(title, [record]);
    const filename = `EPI-card-${record.id || 'record'}-${fileStamp()}.pdf`;
    await deliverPdf(action, blob, filename, title, '1 card');
  } catch (e) {
    if (e && e.name === 'AbortError') { backupMsg('Share cancelled.'); return; }
    console.error('single card export failed', e);
    backupMsg('The card could not be created on this device.', true);
  }
}

// Same flow for Defaulters lists (address-wise / vaccine-wise / covered).
async function runDefaultersExportFlow(title, results, slug){
  if (!results || !results.length) { ((typeof alertDialog==='function')?alertDialog('There is Nothing'):backupMsg('There is Nothing', true)); return; }
  const action = await chooseAction();
  if (!action) return;
  const style = await chooseExportStyle();
  if (!style) return;

  backupMsg(`Creating PDF${action === 'share' ? ' to share' : ''}… please wait.`);
  await new Promise(res => setTimeout(res, 30));
  const slugFull = slug + (style === 'card' ? '-cards' : '');
  try {
    const blob = style === 'card' ? await buildDefaultersCardsPdf(title, results) : await buildDefaultersPdf(title, results);
    const filename = `EPI-${slugFull}-${fileStamp()}.pdf`;
    await deliverPdf(action, blob, filename, title, `${results.length} record(s)`);
  } catch (e) {
    if (e && e.name === 'AbortError') { backupMsg('Share cancelled.'); return; }
    console.error('defaulters export failed', e);
    backupMsg('PDF could not be created on this device.', true);
  }
}

// (The "Save All Records as PDF" button was removed from the Results Menu; exportRecordsPdf() above is kept in case it is needed again.)
document.getElementById('btnPdfDrill').addEventListener('click', () => {
  const filenameBase = (typeof resultsFileName === 'function')
    ? resultsFileName(currentAgeKey, currentDrillLabel)
    : null;
  const breadcrumb = (typeof resultsBreadcrumb === 'function')
    ? resultsBreadcrumb(currentAgeKey, currentDrillLabel)
    : null;
  runRecordsExportFlow(visibleTitle('drillTitle', 'Vaccine List'), lastRendered['drillDetailTable'], 'vaccine', filenameBase, breadcrumb);
});
