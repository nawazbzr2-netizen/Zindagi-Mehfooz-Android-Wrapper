// ============================================================
// Merge & Export Daily Immunization Reports
// Builds ONE combined PDF per Vaccinator/Centre matching the
// editable Daily Registry template:
//   - Header: same text as the official report (centre, Vaccinator Name,
//     date range, Total Rows) so it can be inserted again unchanged
//   - Full child data in every column; 9 rows per page
// ============================================================

function _safeFilePart(s){
  return String(s || 'Unknown')
    .replace(/[\/\\:*?"<>|]/g, '-')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 60) || 'Unknown';
}

function _dmy(d){
  if (!d || !d.year) return '';
  return String(d.day).padStart(2,'0') + '/' + String(d.month).padStart(2,'0') + '/' + d.year;
}

// Filename date parts: "01-09-2026", "29-09-26"
function _fileDateFull(d){
  if (!d || !d.year) return '';
  return String(d.day).padStart(2,'0') + '-' + String(d.month).padStart(2,'0') + '-' + d.year;
}
function _fileDateShortYY(d){
  if (!d || !d.year) return '';
  const yy = String(d.year).slice(-2);
  return String(d.day).padStart(2,'0') + '-' + String(d.month).padStart(2,'0') + '-' + yy;
}

// Date span for filename: 01-09-2026_29-09-26 (or single day if same)
function _dateRangeFileParts(rows){
  let minK = null, maxK = null, minD = null, maxD = null;
  for (const r of rows || []) {
    const d = r.vaccDate;
    if (!d || !d.year) continue;
    const k = d.year * 10000 + d.month * 100 + d.day;
    if (minK == null || k < minK) { minK = k; minD = d; }
    if (maxK == null || k > maxK) { maxK = k; maxD = d; }
  }
  if (!minD) return '';
  const a = _fileDateFull(minD);
  const b = _fileDateShortYY(maxD);
  if (_fileDateFull(minD) === _fileDateFull(maxD)) return a;
  return a + '_' + b;
}

// Default: Daily_Immunization_Report_(Vaccinator|Centre)_01-09-2026_29-09-26.pdf
// Prefer Vaccinator Name when available; otherwise Centre name.
function _exportFileName(g){
  const who = (g.vacLabel && g.vacLabel.trim()) || (g.cenLabel && g.cenLabel.trim()) || 'Unknown';
  const safeWho = _safeFilePart(who).replace(/\s+/g, '_');
  const range = _dateRangeFileParts(g.rows);
  let base = 'Daily_Immunization_Report_' + safeWho;
  if (range) base += '_' + range;
  return base + '.pdf';
}

function _groupKeyFromVisit(v, rec){
  const vac = (v && v.vaccinatorName) || rec.vaccinatorName || '';
  const cen = (v && v.centerName) || rec.centerName || rec.facility || '';
  const vacT = String(vac).trim();
  const cenT = String(cen).trim();
  if (vacT) return { key: 'v:' + vacT.toLowerCase(), vacLabel: vacT, cenLabel: cenT || '' };
  if (cenT) return { key: 'c:' + cenT.toLowerCase(), vacLabel: '', cenLabel: cenT };
  return { key: 'unknown', vacLabel: 'Unknown', cenLabel: '' };
}

// One row per visit under each vaccinator/centre (all days merged).
function groupDailyRowsByVaccinator(store){
  const groups = {}; // key -> { vacLabel, cenLabel, rows: [] }
  const all = Object.values(store || {});

  for (const rec of all) {
    const visits = (rec.visits && rec.visits.length)
      ? rec.visits
      : [{ vaccDate: rec.vaccDate, vaccinatorName: rec.vaccinatorName, centerName: rec.centerName, doses: rec.doses }];

    for (const v of visits) {
      const g = _groupKeyFromVisit(v, rec);
      if (!groups[g.key]) groups[g.key] = { vacLabel: g.vacLabel, cenLabel: g.cenLabel, rows: [] };
      // Prefer non-empty centre if a later visit carries one
      if (g.cenLabel && !groups[g.key].cenLabel) groups[g.key].cenLabel = g.cenLabel;
      if (g.vacLabel && !groups[g.key].vacLabel) groups[g.key].vacLabel = g.vacLabel;

      // Print back exactly what the ORIGINAL report showed in the Identifier
      // cell (e.g. "OUT OF UC"). Records saved by an older version of the app
      // have no such text, so they fall back to the app's own label.
      let statusLine = '';
      if (v && typeof v.idStatusText === 'string') statusLine = v.idStatusText;
      else if (rec.outOfDistrict) statusLine = 'OUT FROM DISTRICT';
      else if (rec.outOfTaluka) statusLine = 'OUT FROM TALUKA';
      else if (rec.outOfUc) statusLine = 'OUT OF UC';

      const doses = { ...(v.doses || rec.doses || {}) };
      if (v && v.paracetamol) doses.Paracetamol = v.paracetamol;
      groups[g.key].rows.push({
        epiNo: rec.epiNo || '',
        qr: rec.id || '',
        statusLine: statusLine,
        name: rec.name || '',
        fatherName: rec.fatherName || '',
        dob: rec.dob,
        gender: rec.gender || '',
        address: rec.address || '',
        vaccDate: v.vaccDate || rec.vaccDate,
        doses: doses
      });
    }
  }

  // Keep the order the rows had in the original report(s). Only when several
  // days are merged are rows grouped by date (stable sort keeps each day's
  // original order).
  Object.keys(groups).forEach(k => {
    groups[k].rows.sort((a, b) => {
      const da = a.vaccDate, db = b.vaccDate;
      if (da && db) {
        const ka = da.year * 10000 + da.month * 100 + da.day;
        const kb = db.year * 10000 + db.month * 100 + db.day;
        return ka - kb;
      }
      return 0;
    });
  });
  return groups;
}

function _dailyStoreStats(store){
  const files = new Set();
  const dates = new Set();
  for (const id in store) {
    const rec = store[id];
    (rec.sources || []).forEach(s => {
      if (typeof sourceKey === 'function') files.add(sourceKey(sourceEntryName(s), sourceEntrySize(s)));
      else files.add(typeof s === 'string' ? s : (s && s.name) || '');
    });
    const visits = (rec.visits && rec.visits.length) ? rec.visits : [{ vaccDate: rec.vaccDate }];
    visits.forEach(v => {
      if (v.vaccDate && v.vaccDate.year) {
        dates.add(v.vaccDate.year + '-' + String(v.vaccDate.month).padStart(2,'0') + '-' + String(v.vaccDate.day).padStart(2,'0'));
      }
    });
  }
  return { fileCount: files.size, dateCount: dates.size, recordCount: Object.keys(store).length };
}

function _wrapCell(text, maxW, size, bold){
  const raw = String(text == null ? '' : text);
  if (!raw.trim()) return [''];
  const paragraphs = raw.split('\n');
  const lines = [];
  for (const para of paragraphs) {
    const words = para.split(/\s+/).filter(Boolean);
    if (!words.length) { lines.push(''); continue; }
    let cur = '';
    for (const word of words) {
      const test = cur ? cur + ' ' + word : word;
      if (measureText(test, size, bold) <= maxW) { cur = test; continue; }
      if (cur) lines.push(cur);
      if (measureText(word, size, bold) <= maxW) { cur = word; continue; }
      let piece = '';
      for (const ch of word) {
        if (piece && measureText(piece + ch, size, bold) > maxW) { lines.push(piece); piece = ch; }
        else piece += ch;
      }
      cur = piece;
    }
    if (cur) lines.push(cur);
  }
  return lines.length ? lines : [''];
}

// Official Daily Registry layout matching the editable blank template:
//   - Header left: Centre name (required); if vaccinator also present:
//       BHU Garhi Chakar (Centre)
//       Muhammad Nawaz (Vaccinator Name)
//   - Header right: date range + Total Rows
//       01/09/26 - 29/09/26
//       Total Rows: 149
//   - Full child data in every column
//   - Max 9 data rows per page
// ============================================================

function _shortDateYY(d){
  if (!d || !d.year) return '';
  const yy = String(d.year).slice(-2);
  return String(d.day).padStart(2,'0') + '/' + String(d.month).padStart(2,'0') + '/' + yy;
}

function _dateRangeHeader(rows){
  let minK = null, maxK = null, minD = null, maxD = null;
  for (const r of rows || []) {
    const d = r.vaccDate;
    if (!d || !d.year) continue;
    const k = d.year * 10000 + d.month * 100 + d.day;
    if (minK == null || k < minK) { minK = k; minD = d; }
    if (maxK == null || k > maxK) { maxK = k; maxD = d; }
  }
  if (!minD) return '';
  const a = _shortDateYY(minD), b = _shortDateYY(maxD);
  return a === b ? a : (a + ' - ' + b);
}

async function buildDailyRegistryPdf(rows, centreName, vaccinatorName){
  // Reproduces the official Daily Registry page so the exported file can be
  // inserted again with "Insert Daily Immunization Report" and read back
  // exactly like the original: same header text (centre, vaccinator, date
  // range, Total Rows), same Identifier cell (EPI No / QR / status), same
  // DOB split, same "value + morning-fixed" dose cells, 9 rows per page.
  // Text is written as page content (that is what the app's reader parses);
  // each cell also carries a white-backed fillable field so it can be edited.
  const PT_W = 892, PT_H = 595;
  const ROWS_PER_PAGE = 9;
  const XS = [25,103,181,258,293,328,405,478,516,554,586,618,650,682,714,748,782,816,867];
  const KEYS = ['id','name','father','dob','gender','address','vdate','BCG','HepB','OPV','ROTA','IPV','Penta','PCV','Measles','TCV','TT','Para'];
  const HEAD = [['Identifier'],['Name'],['Father/Husband'],['DOB','or'],['Gende','r'],['Contact /','Address'],['Vaccination','Date'],
    ['BCG'],['HepB'],['OPV'],['ROTA'],['IPV'],['Penta'],['PCV'],['Measles'],['TCV'],['TT'],['Paracetamol','Given']];
  const HEAD_FS = [10,10,10,10,10,10,10,10,10,10,10,10,10,10,8,10,10,8];
  const GROUP_TOP = 129, HEAD_TOP = 149, DATA_TOP = 180, ROW_H = 40;
  const FS = 6.5, LH = 7.6, PAD = 2.5;

  function centered(page, txt, x0, x1, yBase, size, bold){
    page.text((x0 + x1) / 2 - measureText(txt, size, !!bold) / 2, yBase, txt, size, !!bold, '#000');
  }

  function cellLines(row, key, maxW){
    if (key === 'id') {
      const parts = [];
      if (row.epiNo) parts.push(String(row.epiNo));
      if (row.qr) parts.push(String(row.qr));
      if (row.statusLine) parts.push(row.statusLine);
      return parts;
    }
    if (key === 'name') return _wrapCell(row.name, maxW, FS, false);
    if (key === 'father') return _wrapCell(row.fatherName, maxW, FS, false);
    if (key === 'dob') {
      const dd = row.dob && row.dob.year ? String(row.dob.day).padStart(2,'0') + '/' + String(row.dob.month).padStart(2,'0') + '/' : '';
      return dd ? [dd, String(row.dob.year)] : [''];
    }
    if (key === 'gender') return [row.gender || ''];
    if (key === 'address') return _wrapCell(row.address, maxW, FS, false);
    if (key === 'vdate') return [_dmy(row.vaccDate)];
    if (key === 'Para') {
      const v = row.doses ? row.doses.Paracetamol : '';
      const shown = (v === 'Y' || v === 'y' || v === 'Yes' || v === '1') ? 'Yes' : (v || '');
      return [shown];
    }
    const v = row.doses ? row.doses[key] : '';
    if (v == null || v === '') return [''];
    const val = String(v).trim();
    return [val, 'morning-', 'fixed'];
  }

  // Header text (same wording / positions as the official report)
  function rangeText(){
    let minK = null, maxK = null, minD = null, maxD = null;
    for (const r of rows) {
      const d = r.vaccDate; if (!d || !d.year) continue;
      const k = d.year * 10000 + d.month * 100 + d.day;
      if (minK == null || k < minK) { minK = k; minD = d; }
      if (maxK == null || k > maxK) { maxK = k; maxD = d; }
    }
    return minD ? [_dmy(minD), _dmy(maxD)] : ['', ''];
  }
  const centre = String(centreName || '').trim();
  const vac = String(vaccinatorName || '').trim();
  const rng = rangeText();

  const pages = [];
  const total = Math.max(1, Math.ceil(rows.length / ROWS_PER_PAGE));

  for (let p = 0; p < total; p++) {
    const page = new PdfPage(PT_W, PT_H);
    const chunk = rows.slice(p * ROWS_PER_PAGE, (p + 1) * ROWS_PER_PAGE);
    const nrows = ROWS_PER_PAGE;
    const bottom = DATA_TOP + nrows * ROW_H;
    const X0 = XS[0], X1 = XS[XS.length - 1];

    // Logos + title
    page.image('RegL1', 25, 20, 60, 22);
    page.image('RegL2', 742, 19, 36, 37);
    page.image('RegL3', 785, 21, 28, 34);
    page.text(85, 41, 'Daily Registry', 18, false, '#000');

    // Header text
    if (centre) page.text(32, 75, centre, 10, false, '#000');
    if (vac) page.text(32, 100, 'Vaccinator Name: ' + vac, 10, false, '#000');
    if (rng[0]) {
      page.text(613, 82, rng[0], 10, false, '#000');
      page.text(680, 81, '-', 10, false, '#000');
      page.text(694, 82, rng[1], 10, false, '#000');
    }
    page.text(611, 99, 'Total Rows: ' + rows.length, 10, false, '#000');

    // Grid
    page.strokeColor('#000'); page.lineWidth(0.25);
    XS.forEach(x => page.line(x, HEAD_TOP, x, bottom));
    for (let r = 0; r <= nrows; r++) page.line(X0, DATA_TOP + r * ROW_H, X1, DATA_TOP + r * ROW_H);
    [478, 554, 816].forEach(x => page.line(x, GROUP_TOP, x, HEAD_TOP));
    page.lineWidth(1);
    page.rect(X0, GROUP_TOP, X1 - X0, bottom - GROUP_TOP, 'S');
    page.line(X0, HEAD_TOP, X1, HEAD_TOP);

    centered(page, 'Pedaishi', 478, 554, 144, 10);
    centered(page, 'Tikajat ki Tafseel', 554, 816, 144, 10);

    const mid = (HEAD_TOP + DATA_TOP) / 2;
    HEAD.forEach((l, i) => {
      const fs = HEAD_FS[i];
      if (l.length === 1) centered(page, l[0], XS[i], XS[i + 1], mid + fs * 0.35, fs);
      else {
        centered(page, l[0], XS[i], XS[i + 1], mid - fs * 0.3, fs);
        centered(page, l[1], XS[i], XS[i + 1], mid + fs * 0.95, fs);
      }
    });

    // Data rows — each row's cells are written together, Identifier first
    for (let ri = 0; ri < nrows; ri++) {
      const row = chunk[ri] || null;
      const top = DATA_TOP + ri * ROW_H;
      const maxLines = Math.floor((ROW_H - PAD) / LH);
      KEYS.forEach((k, ci) => {
        const maxW = XS[ci + 1] - XS[ci] - PAD * 2;
        let lines = row ? cellLines(row, k, maxW) : [];
        if (lines.length > maxLines) lines = lines.slice(0, maxLines);
        const blockH = lines.length * LH;
        const start = top + (ROW_H - blockH) / 2 + FS;
        lines.forEach((ln, li) => {
          if (ln) centered(page, ln, XS[ci], XS[ci + 1], start + li * LH, FS);
        });
        // Editable field on top of the cell (white background, same text)
        page.field({
          name: 'p' + (p + 1) + '_r' + (ri + 1) + '_' + k,
          x: XS[ci] + 0.9, yTop: top + 0.9, w: XS[ci + 1] - XS[ci] - 1.8, h: ROW_H - 1.8,
          lines: lines.filter(l => l !== ''), size: FS, lineHeight: LH,
          multiline: true, align: 'center', bg: true
        });
      });
    }

    centered(page, 'Page ' + (p + 1), 0, PT_W, 578, 10);
    pages.push(page);
  }
  return assemblePdf(pages, PT_W, PT_H);
}

async function mergeAndExportDailyImmunization(){
  const store = loadStore();
  const stats = _dailyStoreStats(store);
  if (!stats.recordCount) {
    if (typeof alertDialog === 'function') await alertDialog('No processed Daily Immunization Reports found in the app.');
    else if (typeof backupMsg === 'function') backupMsg('No Daily Immunization data to export.', true);
    return;
  }

  const groups = groupDailyRowsByVaccinator(store);
  const groupKeys = Object.keys(groups);
  if (!groupKeys.length) {
    if (typeof alertDialog === 'function') await alertDialog('Could not group records by vaccinator/centre.');
    return;
  }

  const summary = groupKeys.map(k => {
    const g = groups[k];
    const who = g.vacLabel || g.cenLabel || 'Unknown';
    return '• ' + who + ': ' + g.rows.length + ' row(s)';
  }).join('\n');

  const ok = await confirmDialog(
    'Merge & export ' + stats.fileCount + ' processed Daily Immunization Report file(s) ' +
    '(' + stats.dateCount + ' day(s), ' + stats.recordCount + ' child/woman record(s)) into ' +
    groupKeys.length + ' Daily Registry PDF(s)?\n\n' +
    summary +
    '\n\nPDFs will be saved under Download → Daily Immunization.\n' +
    'After a successful export, ALL processed Daily Immunization data will be cleared from the app.',
    'Merge & Export',
    'Cancel'
  );
  if (!ok) return;

  if (typeof NativeBridge !== 'undefined' && NativeBridge.primeNotifications) {
    try { NativeBridge.primeNotifications(); } catch (e) {}
  }

  let exported = 0;
  const errors = [];

  for (const k of groupKeys) {
    const g = groups[k];
    if (!g.rows.length) continue;
    const label = g.vacLabel || g.cenLabel || 'Unknown';
    const fileBase = _exportFileName(g);
    // Prefer subfolder under Download; fallback to flat name if bridge ignores path
    const filename = 'Daily Immunization/' + fileBase;

    try {
      const blob = await buildDailyRegistryPdf(g.rows, g.cenLabel || '', g.vacLabel || '');
      const saved = downloadBlobFile(filename, blob);
      if (!saved) {
        downloadBlobFile(fileBase, blob);
      }
      exported++;
      await new Promise(r => setTimeout(r, 400));
    } catch (err) {
      console.error('merge export failed for', label, err);
      errors.push(label + ': ' + (err && err.message ? err.message : String(err)));
    }
  }

  if (!exported) {
    if (typeof alertDialog === 'function') {
      await alertDialog('Export failed. No PDF was saved.\n' + (errors.length ? errors.join('\n') : ''));
    }
    return;
  }

  // Clear processed Daily Immunization data (keep defaulters & QR)
  saveStore({});
  try { if (typeof renderResults === 'function') renderResults(loadStore(), true); } catch (e) {}
  try { if (typeof renderProcessedFileLists === 'function') renderProcessedFileLists(); } catch (e) {}
  try { if (typeof updateProcessButtonState === 'function') updateProcessButtonState(); } catch (e) {}
  try { if (typeof updateStorageNote === 'function') updateStorageNote(); } catch (e) {}

  const msg =
    'Saved ' + exported + ' Daily Registry PDF(s) to Download → Daily Immunization.\n' +
    'Processed Daily Immunization data has been cleared from the app.' +
    (errors.length ? '\n\nSome groups failed:\n' + errors.join('\n') : '');

  if (typeof alertDialog === 'function') await alertDialog(msg);
  else if (typeof backupMsg === 'function') backupMsg(msg);
}

window.mergeAndExportDailyImmunization = mergeAndExportDailyImmunization;

// Main Insert-files menu button
document.addEventListener('DOMContentLoaded', function(){
  const btn = document.getElementById('btnMergeExportDaily');
  if (btn && !btn.dataset.mergeBound) {
    btn.dataset.mergeBound = '1';
    btn.addEventListener('click', function(){
      if (typeof mergeAndExportDailyImmunization === 'function') mergeAndExportDailyImmunization();
      else if (typeof alertDialog === 'function') alertDialog('Merge & Export is not available.');
    });
  }
});
(function(){
  const btn = document.getElementById('btnMergeExportDaily');
  if (btn && !btn.dataset.mergeBound) {
    btn.dataset.mergeBound = '1';
    btn.addEventListener('click', function(){
      if (typeof mergeAndExportDailyImmunization === 'function') mergeAndExportDailyImmunization();
      else if (typeof alertDialog === 'function') alertDialog('Merge & Export is not available.');
    });
  }
})();
