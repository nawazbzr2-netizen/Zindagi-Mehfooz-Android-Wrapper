// ============================================================
// report-filter.js — Month + Vaccinator/Center filter for every
// Daily-Immunization-Report-driven result (In UC, Out of UC, All
// Category, 0-11/12-23/24-59, All T-D, drill lists, village-wise,
// PDF/CSV exports). Applied in results.js right after the existing
// UC/facility filter, so it flows through everything downstream for
// free. Search and "Results by Date" are untouched on purpose:
// Search always searches everything, and Results by Date already has
// its own calendar-month grouping (see date-stock.js).
//
// Month-first-then-vaccinator: the Vaccinator/Center picker's option
// list is scoped to whichever month(s) are currently selected, so
// picking a month narrows which vaccinators/centres show up next.
// ============================================================

const REPORT_FILTER_KEY = 'epi_report_filter_v2';

function reportFilterMonthKey(vd){
  if (!vd || !vd.year || !vd.month) return '';
  return vd.year + '-' + String(vd.month).padStart(2, '0');
}
function reportFilterVcKey(v){
  return (v.vaccinatorName || '—') + '  |  ' + (v.centerName || '—');
}
const REPORT_FILTER_MONTH_NAMES = ['','January','February','March','April','May','June','July','August','September','October','November','December'];
const REPORT_FILTER_MONTH_NAMES_SHORT = ['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function reportFilterMonthLabel(key, short){
  const parts = key.split('-');
  const names = short ? REPORT_FILTER_MONTH_NAMES_SHORT : REPORT_FILTER_MONTH_NAMES;
  return (names[+parts[1]] || parts[1]) + ' ' + parts[0];
}

function loadReportFilterState(){
  try {
    const raw = localStorage.getItem(REPORT_FILTER_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        months: parsed.months === 'all' ? 'all' : new Set(parsed.months || []),
        vc: parsed.vc === 'all' ? 'all' : new Set(parsed.vc || [])
      };
    }
  } catch (e) { /* ignore */ }
  // Nothing saved yet: resolved to a real month set the first time
  // records exist (see resolveDefaultReportMonthsIfNeeded below).
  return { months: 'unset', vc: 'all' };
}
let reportFilterState = loadReportFilterState();
function saveReportFilterState(){
  try {
    localStorage.setItem(REPORT_FILTER_KEY, JSON.stringify({
      months: reportFilterState.months === 'all' ? 'all' : Array.from(reportFilterState.months),
      vc: reportFilterState.vc === 'all' ? 'all' : Array.from(reportFilterState.vc)
    }));
  } catch (e) { /* ignore */ }
}

function reportFilterAllVisits(r){
  return (r.visits && r.visits.length)
    ? r.visits
    : [{ vaccDate: r.vaccDate, vaccinatorName: r.vaccinatorName, centerName: r.centerName, doses: r.doses, idStatusText: r.idStatusText, paracetamol: r.paracetamol }];
}

// First time ever (nothing saved): default to the current calendar month if
// it has any data, else the most recent month that does — so a fresh
// install lands on "this month's work", not everything merged together.
// Resolved once into a real Set, then saved so it sticks.
function resolveDefaultReportMonthsIfNeeded(records){
  if (reportFilterState.months !== 'unset') return;
  const counts = {};
  records.forEach(r => reportFilterAllVisits(r).forEach(v => {
    const k = reportFilterMonthKey(v.vaccDate);
    if (k) counts[k] = (counts[k] || 0) + 1;
  }));
  const keys = Object.keys(counts).sort();
  if (!keys.length) { reportFilterState.months = 'all'; return; } // nothing uploaded yet — resolve for real once data exists
  const thisMonth = (typeof currentCalendarMonthKey === 'function') ? currentCalendarMonthKey() : keys[keys.length - 1];
  reportFilterState.months = new Set([counts[thisMonth] ? thisMonth : keys[keys.length - 1]]);
  saveReportFilterState();
}

function distinctReportMonths(records){
  const counts = {};
  records.forEach(r => reportFilterAllVisits(r).forEach(v => {
    const k = reportFilterMonthKey(v.vaccDate);
    if (k) counts[k] = (counts[k] || 0) + 1;
  }));
  return Object.keys(counts).sort().reverse().map(k => ({ key: k, label: reportFilterMonthLabel(k), count: counts[k] }));
}

// Vaccinator/Centre options, scoped to whichever months are selected right
// now (month first, then vaccinator/centre).
function distinctReportVCs(records, monthsFilter){
  const counts = {};
  records.forEach(r => reportFilterAllVisits(r).forEach(v => {
    if (monthsFilter !== 'all' && !monthsFilter.has(reportFilterMonthKey(v.vaccDate))) return;
    const k = reportFilterVcKey(v);
    counts[k] = (counts[k] || 0) + 1;
  }));
  return Object.keys(counts).sort().map(k => {
    const bits = k.split('  |  ');
    return { key: k, vaccinator: bits[0], center: bits[1], label: bits[0] + ' — ' + bits[1], count: counts[k] };
  });
}

// Rebuilds each record down to only the visits matching the active filter;
// a record with no matching visit is dropped entirely. doses / vaccDate /
// vaccinatorName / centerName at the top level are recomputed from the
// surviving visits only, so every downstream dashboard, drill list and PDF
// reflects ONLY the filtered Daily Immunization Report data.
function applyReportFilter(records){
  resolveDefaultReportMonthsIfNeeded(records);
  const months = reportFilterState.months;
  const vc = reportFilterState.vc;
  if (months === 'all' && vc === 'all') return records;
  const out = [];
  for (const r of records) {
    const visits = reportFilterAllVisits(r);
    const kept = visits.filter(v => {
      if (months !== 'all' && !months.has(reportFilterMonthKey(v.vaccDate))) return false;
      if (vc !== 'all' && !vc.has(reportFilterVcKey(v))) return false;
      return true;
    });
    if (!kept.length) continue;
    const sorted = kept.slice().sort((a, b) => compareDateObjs(a.vaccDate, b.vaccDate));
    const latest = sorted[sorted.length - 1];
    let mergedDoses = {};
    kept.forEach(v => { mergedDoses = mergeDoses(mergedDoses, v.doses || {}); });
    out.push(Object.assign({}, r, { visits: kept, vaccDate: latest.vaccDate, vaccinatorName: latest.vaccinatorName, centerName: latest.centerName, doses: mergedDoses }));
  }
  return out;
}

function reportFilterIsAll(){
  return reportFilterState.months === 'all' && reportFilterState.vc === 'all';
}
function reportFilterMonthsSummary(){
  if (reportFilterState.months === 'all' || reportFilterState.months === 'unset') return 'All Months';
  const n = reportFilterState.months.size;
  if (!n) return 'All Months';
  if (n === 1) return reportFilterMonthLabel(Array.from(reportFilterState.months)[0], true);
  return n + ' Months';
}
function reportFilterVcSummary(){
  if (reportFilterState.vc === 'all') return 'All';
  const n = reportFilterState.vc.size;
  if (!n) return 'All';
  if (n === 1) return Array.from(reportFilterState.vc)[0].split('  |  ')[0];
  return n + ' Selected';
}

// Sets the Month selection (Set of 'YYYY-MM' keys, or 'all') and, since the
// Vaccinator/Centre list is scoped by month, drops any selected vaccinator
// that no longer has data within the new month selection.
function setReportFilterMonths(monthsSetOrAll, records){
  reportFilterState.months = monthsSetOrAll;
  if (reportFilterState.vc !== 'all') {
    const valid = new Set(distinctReportVCs(records, reportFilterState.months).map(o => o.key));
    reportFilterState.vc = new Set(Array.from(reportFilterState.vc).filter(k => valid.has(k)));
    if (!reportFilterState.vc.size) reportFilterState.vc = 'all';
  }
  saveReportFilterState();
}
function setReportFilterVc(vcSetOrAll){
  reportFilterState.vc = vcSetOrAll;
  saveReportFilterState();
}

// Keeps the hub's two filter buttons showing the current selection.
function updateReportFilterLabels(){
  const m = document.getElementById('reportMonthFilterLabel');
  const v = document.getElementById('reportVcFilterLabel');
  if (m) m.textContent = reportFilterMonthsSummary();
  if (v) v.textContent = reportFilterVcSummary();
}
